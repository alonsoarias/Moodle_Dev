<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer class for the usage monitor report.
 *
 * @package    report_usage_monitor
 * @copyright  2025 Soporte IngeWeb <soporte@ingeweb.co>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace report_usage_monitor\output;

defined('MOODLE_INTERNAL') || die();

use plugin_renderer_base;

/**
 * Renderer for the usage monitor report.
 */
class renderer extends plugin_renderer_base {

    /**
     * Render the dashboard.
     *
     * @param dashboard $dashboard The dashboard renderable
     * @return string HTML output
     */
    public function render_dashboard(dashboard $dashboard): string {
        $data = $dashboard->export_for_template($this);

        // Include the AMD module for charts.
        $this->page->requires->js_call_amd(
            'report_usage_monitor/dashboard_charts',
            'init',
            [json_decode($data['chart_config'], true)]
        );

        return $this->render_from_template('report_usage_monitor/dashboard', $data);
    }
}
